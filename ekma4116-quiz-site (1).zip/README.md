# EKMA4116 Quiz Site

This repository hosts a single-page quiz app (HTML/CSS/JS). It’s ready for GitHub Pages.

## How to deploy (GitHub Pages)

1. **Create a new repository** on GitHub (e.g., `ekma4116-quiz-site`).  
2. **Upload these files** (at minimum `index.html`).  
   - Option A: Drag & drop via GitHub web UI.  
   - Option B: Use `git` (see commands below).
3. Go to **Settings → Pages**:  
   - **Source**: `Deploy from a branch`  
   - **Branch**: `main` (or `master`) / **Folder**: `/ (root)`  
   - Click **Save**.
4. Wait for GitHub Pages to build. Your site URL will look like:  
   `https://<your-username>.github.io/<repo-name>/`

## Update later
Just push a new `index.html` (and any assets). GitHub Pages redeploys automatically.

## Local preview
Open `index.html` in your browser, or serve it locally:
```bash
python3 -m http.server 8080
# then open http://localhost:8080
```

## Optional
- Create `CNAME` file if you want a custom domain.
- Add a `LICENSE` file (MIT recommended) if you plan to share publicly.
